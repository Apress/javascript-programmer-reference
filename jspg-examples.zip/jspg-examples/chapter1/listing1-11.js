var myTest = true;
function testScope() {
    if (true) {
       var myTest = "I am changed!"
    }
    alert(myTest);
}

testScope(); // will alert "I am changed!"
alert(myTest); // will alert "true"
