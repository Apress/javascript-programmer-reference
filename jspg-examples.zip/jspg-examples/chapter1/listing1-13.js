function testScope() {
    myTest = true; // now myTest is global.
    alert(myTest); 
}
testScope();  // will alert "true"
alert(myTest); // will alert "true" as well, because now myTest is global.
