var myArrayOfThings = ["hello", 5, true, {}];
for (var i = 0; i < myArrayOfThings.length; i++) {
    alert(typeof myArrayOfThings[i]);
}
alert(typeof myArrayOfThings);
