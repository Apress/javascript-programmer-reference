var myString = "hello there" // primitive
alert(myString.length); // will alert 11...but length is a property of the String object
alert(typeof myString); // will alert "string"
