if ("Primitive String") {
    alert("Primitive String" == true);
    alert("Primitive String" == false);
}
