function greet(myName) {
    var myAlertString = "Hello " + myName; // Local variable
    (function doAlert() {
        alert(myAlertString);
    })()
}

greet("Kitty");
