var Module = (function() {
    var _privateVariable = "This is private",
        _otherPrivateVariable = "So is this",
        public = {}; // This object will be returned
    function privateMethod() {
        alert("This method is private as well");
    }
    
    public.publicProperty = "This is a public property";
    public.publicMethod = function() {
        alert("This is a public method");
    }
    return public;
})()

alert(Module._privateVariable); // will alert "undefined"
// Module.privateMethod(); // would throw an error if we let it run
alert(Module.publicProperty); // will alert "This is a public property"
Module.publicMethod(); // will alert "This is a public method"
