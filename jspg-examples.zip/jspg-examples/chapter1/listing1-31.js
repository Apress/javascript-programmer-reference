var Module = (function() {
    var _privateVariable = "This is private",
        _otherPrivateVariable = "So is this",
        public = {}; // This object will be returned
    function privateMethod() {
        alert("This method is private as well");
    }
    
    public.publicProperty = "This is a public property";
    public.publicMethod = function() {
        alert("This is a public method");
    }
    return public;
})()

var Module = (function(oldModule) {
    oldModule.newMethod = function() {
        alert("This is a new method!");
    }
    return oldModule;
})(Module)
