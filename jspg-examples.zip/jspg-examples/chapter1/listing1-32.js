var Module = (function() {
    var _privateVariable = "This is private",
        _otherPrivateVariable = "So is this",
        public = {}; // This object will be returned
    function privateMethod() {
        alert("This method is private as well");
    }
    
    public.publicProperty = "This is a public property";
    public.publicMethod = function() {
        alert("This is a public method");
    }
    return public;
})()

Module.sub = (function() {
    var _privateSubVariable = "This is a private variable in the submodule",
    public = {};
    public.publicSubVariable = "This is a public variable in the submodule";
    return public;
})();

