var myParent = {
    a: 10,
    b: 50
}

var myChild = Object.create(myParent);
var myGrandChild = Object.create(myChild);

myParent.c = "hello";
alert(myChild.c); // will alert "hello"
alert(myGrandChild.c); // will alert "hello"
