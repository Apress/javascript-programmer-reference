function testScope() {
    var myTest = true;
    if (true) {
        var myTest = "I am changed!"
    }
    alert(myTest);
}

testScope(); // will alert "I am changed!" 
