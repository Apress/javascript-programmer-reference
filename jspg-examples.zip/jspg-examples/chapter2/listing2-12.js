var myVar = 5 + 7 * 3 + 4 - 2 * 8;
alert(myVar); // what will this alert?
