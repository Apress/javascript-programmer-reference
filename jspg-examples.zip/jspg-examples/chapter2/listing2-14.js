var myVar = 5 + 6 - 7 + 10;
alert(myVar); // what will this alert?
