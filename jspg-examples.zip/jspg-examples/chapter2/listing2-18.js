function myFunction() {
    var myVariable = "Here"; // myVariable is now limited in scope to myFunction and any scopes we create within myFunction

    // Create a new function within myFunction to demonstrate scope nesting
    function myInternalFunction() {
        alert(myVariable); 
    }
    myInternalFunction(); // call myInternalFunction when myFunction is called
}
myFunction(); // will alert "Here"
alert(myVariable); // will throw an error; myVariable is not defined outside of myFunction().
