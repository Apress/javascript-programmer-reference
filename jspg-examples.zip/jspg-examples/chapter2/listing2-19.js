var myVariable = "This is a global variable";
function myFunction() {
    myVariable = "Global variable has been changed inside a function"; 
    alert(myVariable);
}

alert(myVariable); // will alert "This is a global variable"
myFunction(); // will alert "Global variable has been changed inside a function"
alert(myVariable); // will alert "Global variable has been changed inside a function"
