function testScope() {
    var myTest = true; // myTest is now present in this top level scope.
    function testNestedScope() { // Create a sub-scope within the main scope
        alert(myTest); // Access myTest…but from which scope?
        var myTest = false; // Redefine myTest in this sub-scope.
    }
    testNestedScope();
    alert(myTest);
}

testScope(); // will alert "undefined", and then true.
