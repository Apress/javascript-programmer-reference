function myFunction() {
    myVariable = "Declared in function, default global scope"; 
    alert(myVariable);
}

alert(typeof myVariable); // will alert "undefined" because it wasn't created yet
myFunction(); // will alert " Declared in function, default global scope "
alert(myVariable); // will alert "Declared in function, default global scope "
