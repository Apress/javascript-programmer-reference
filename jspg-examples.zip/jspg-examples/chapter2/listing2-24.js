var myObject = {};
var myOtherObject = myObject; // myOtherObject is now a reference to myObject
myObject.bar = "bar"; // This changes myObject directly
myOtherObject.foo = "foo"; // This changes myObject via reference 
alert(myObject.foo); // will alert "foo"
alert(myOtherObject.bar); // will alert "bar" 
var myInt = 5; // Primitive
var myOtherInt = myInt; // myOtherInt is now its own primitive, there is no reference
myOtherInt++;
myInt--;
alert(myOtherInt); // will alert 6
alert(myInt); // will alert 4
var myPrimitiveString = "My Primitive String";
var myOtherPrimitiveString = myPrimitiveString;
myOtherPrimitiveString += " is now longer."
alert(myOtherPrimitiveString); // Will alert "My Primitive String is now longer."
alert(myPrimitiveString);  // Will alert "My Primitive String"
