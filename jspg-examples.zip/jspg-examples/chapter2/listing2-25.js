var myStringObject = new String("This is an object");
var myOtherStringObject = myStringObject;
myOtherStringObject += " which I just changed into a primitive"; // Type change, so no longer a reference!
alert(myStringObject); // will alert "This is an object"
alert(myOtherStringObject); // will alert "This is an object which I just changed into a primitive"
