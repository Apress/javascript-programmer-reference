var myObject = {};
var myOtherObject = {};
var myThirdObject = myObject;
alert(myObject == myThirdObject); // will alert "true"
alert(myOtherObject == myThirdObject); // will alert "false" 
alert(myObject == myOtherObject); // will alert "false" 
