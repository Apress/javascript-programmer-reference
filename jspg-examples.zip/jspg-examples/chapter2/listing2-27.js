var myObject = {};
myObject.property1 = "This is property1"; // access via dot notation
myObject["property2"] = 5; // access via square brackets
alert(myObject["property1"]); // will alert "This is property1"
alert(myObject.property2); // will alert 5
