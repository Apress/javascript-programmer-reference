function myConstructor() {
    this.property1 = "foo";
    this.property2 = "bar";
    this.method1 = function() {
        alert("Hello World!");
    }
}

var myObject = new myConstructor();
myObject.method1(); // will alert "Hello World!"
