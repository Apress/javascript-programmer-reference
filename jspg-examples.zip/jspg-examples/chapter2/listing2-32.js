var myObjectLiteral = {
    property1: "one",
    property2: "two",
    method1: function() {
        alert("Hello World!");
    }
}
myObjectLiteral.method1(); // will alert "Hello World!"
