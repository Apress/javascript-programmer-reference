var myObjectLiteral = {
    property1: "one",
    property2: "two",
    method1: function() {
        alert("Hello world!");
    }
}
var myChild = Object.create(myObjectLiteral);
