var arrColors = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"];
alert(arrColors.length); // will alert 7
arrColors.length = 10;  // adds three new elements to the array, each set to "undefined"
alert(arrColors[8]); // will alert "undefined"
arrColors.length = 6; // arrColors is now ["red", "orange", "yellow", "green", "blue", "indigo"]
