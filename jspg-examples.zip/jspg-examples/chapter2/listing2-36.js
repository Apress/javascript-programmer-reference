var myArray = new Array();
myArray[0] = "foo";
myArray[1] = "bar"; 
myArray[3] = 4;
alert(myArray.length); // will alert 4
alert(myArray[2]); // will alert "undefined"

var testVar = myArray[498]; // testVar is now "undefined" and no error will be thrown
alert(testVar); // will alert "undefined"
