var myArray = new Array();
myArray[0] = "foo"; // assign "foo" to the first element of the array
myArray[1] = "bar"; // assign "bar" to the second element of the array
myArray["foo"] = "bar"; // create the property "foo" on myArray and give it the value of "bar"
alert(myArray.length); // will alert 2
myArray["2"] = 7; // assign 7 to the third element of the array 
alert(myArray.length); // will alert 3
var strMyIndex = "3";
myArray[strMyIndex] = 8; // will assign 8 to the fourth element of the array
alert(myArray.length); // will alert 4
