var myArray = new Array();
myArray["foo"] = "bar"; // adds a property, not a new element
myArray["new"] = "old"; // adds a property, not a new element
alert(myArray.length); // will alert 0, because no elements have actually been added to the array. 
myArray[0] = 0; // Adds a new element to the array
alert(myArray.length); // will alert 1
