var myArrayObject = new Array(4); // creates an array with 4 undefined elements
var myOtherArray = new Array(4, 2, 5, 2, 7); // creates an array with those values
alert(myArrayObject.length); // will alert 4
alert(myOtherArray.length); // will alert 5
