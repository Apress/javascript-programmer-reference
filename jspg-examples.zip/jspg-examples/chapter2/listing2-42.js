var myColors = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"];
for (var i = 0; i < myColors.length; i++) {
    alert(myColors[i]); // will alert each color one at a time
}
