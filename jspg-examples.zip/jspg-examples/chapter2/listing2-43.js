var myColors = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"];
for ( var i = 0, color; color = myColors[i]; i++) {
    // Inside of the loop, the variable color will contain the value at the current index
    alert(color); // will alert each color one at a time
}
