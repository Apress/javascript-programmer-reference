var myColors = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"];
myColors.forEach(function(color) {
    alert(color); // will alert each of the colors, one at a time
});
