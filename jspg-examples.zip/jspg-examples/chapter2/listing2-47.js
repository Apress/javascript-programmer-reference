function saySomething(strMessage, strTarget) {
    alert(strMessage + " " + strTarget);
}
saySomething("Hello", "world"); // will alert "Hello world"
