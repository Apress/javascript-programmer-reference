function myFunction() {
    function myInternalFunction() {
        return 10;
    }
    return myInternalFunction();
    function myInternalFunction() {
        return 20;
    }
}
alert(myFunction()); // What will this alert?
