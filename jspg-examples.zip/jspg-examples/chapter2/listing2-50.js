function myFunction() {
    function myInternalFunction() {
        return 10;
    }
    function myInternalFunction() {
        return 20;
    }
    return myInternalFunction();
}
alert(myFunction()); // What will this alert?
