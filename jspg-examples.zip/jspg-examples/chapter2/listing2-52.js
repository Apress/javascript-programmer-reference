function myTestFunction() {
    var myInternalFunction = function() {
        return "Hello World.";
    }
    return myInternalFunction();
    var myInternalFunction = function() {
        return "Second Definition.";
    }
}
alert(myTestFunction()); // What will this alert? 
