function myFunction() {
    alert('Hello world!');
}
new myFunction; // will alert "Hello world!"
