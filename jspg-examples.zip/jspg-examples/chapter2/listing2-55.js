// A common convention for constructors is to capitalize their first letter.
function Kitty() {
    this.soft = true;
    this.temperature = "warm";
    this.vocalize = function() {
        alert('Purr, purr, purr');
    }
}

var myKitty = new Kitty; // create a new kitty.
alert(myKitty.soft); // will alert true
alert(myKitty.temperature); // will alert "warm"
myKitty.vocalize(); // will alert "Purr, purr, purr"
