var contextObject = {
    testContext: 10
}
var otherContextObject = {
    testContext: "Hello World!"
}

var testContext = 15; // Global variable

function testFunction() {
    alert(this.testContext);
}

testFunction(); // This will alert 15
testFunction.call(contextObject); // Will alert 10
testFunction.apply(otherContextObject); // Will alert "Hello World!"
