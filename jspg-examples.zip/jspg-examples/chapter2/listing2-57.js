function alertGenres(authorName) {
    if (authorName === "Neil Gaiman") {
        alert("Fantasy");
    } else if (authorName === "Octavia Butler") {
        alert("Science Fiction");
    } else if (authorName === "Roger Zelazny") {
        alert("Science Fiction and Fantasy");
    } else {
        alert("Unknown author.");
    }
}

alertGenres("Roger Zelazny"); // will alert "Science Fiction and Fantasy"
alertGenres("Arthur C. Clarke"); // will alert "Unknown author."
