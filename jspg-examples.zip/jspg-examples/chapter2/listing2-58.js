var myColor = "yellow"; 
switch (myColor) {
    case "red": 
        alert("myColor was set to red");
        break;
    case "yellow":
        alert("myColor was set to yellow");
    case "green":
        alert("myColor was set to green");
    default:
        alert("myColor was an unknown color");
}
