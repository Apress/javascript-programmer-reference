for (var i =0; i < 10; i++) {
    alert(i); // will alert 0 through 9 one at a time
}
