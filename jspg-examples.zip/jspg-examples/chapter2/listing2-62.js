var myObject = {
    prop1: "value1",
    prop2: "value2",
    prop3: true,
    prop4: 100
}
var strAlert = "";
for (var prop in myObject) {
    strAlert += prop + " : " + myObject[prop] + "\n";
}
alert(strAlert);
