var counter = 0;
while (counter < 10) {
    alert(counter);
    counter++;
}
