var counter = 0;
do {
    alert(counter);
    counter++;
} while (counter < 10)
