myVar = 5; // defined without var keyword, so it is global
alert(window.myVar); // will alert 5
