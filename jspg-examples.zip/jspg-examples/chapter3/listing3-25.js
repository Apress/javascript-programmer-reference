if (document.addEventListener) {
  // DOM events available, so just use them.
  window.addEventHandler = function(targetEl, eventType, handler) {
    targetEl.addEventListener(eventType, handler, false);
    return handler;
  };
  window.removeEventHandler = function(targetEl, eventType, handler) {
    targetEl.removeEventListener(eventType, handler, false);
  }
} else {
  // Internet Explorer. Fix context problems as well as create alias.
  window.addEventHandler = function(targetEl, eventType, handler) {
    var fixContext = function() {
      return handler.apply(targetEl, arguments);
    };
    targetEl.attachEvent("on" + eventType, fixContext);
    return fixContext;
  }
  
  window.removeEventHandler = function(targetEl, eventType, handler) {
    targetEl.detachEvent("on" + eventType, handler);
  }
}
