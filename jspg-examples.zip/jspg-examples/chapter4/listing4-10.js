var myXhrDefs = {
    intCacheDuration: 14400,
    cacheName: "ajax-test",
    strMethod : "GET",
    strUrl : "http://127.0.0.1:8020/developers-guide/chapter-4/ajax-test.txt",
    intTimeout: 3000,
    postData: null,
    boolAsync: true,
    successCallback: function(objEvent) {
        // Do things when the request is successful
        console.log(objEvent.responseText);
    },
    errorCallback: function(objEvent) {
        // Do things when there is an error in the request.
        console.error("The XHR failed with error ", objEvent.status);
    },
    timeoutCallback: function() {
        // Do things when a timeout occurs.
        console.error("The XHR timed out.");
    }
}
