// Either perform an asynchronous call to a service and cache it with a timestamp,
// or if the service has already been called and cached, just use that if the data isn't
// too old.  If the data is too old, perform the asynchronous call again and cache the
// results with a new timestamp.
function cachedXHR(myXhrDefs) {
    var fetchNewData = false,
        now = new Date(),
        lastTimeStamp = localStorage.getItem(myXhrDefs.cacheName + "-timestamp");

    // Does the cache even have the specified item?
    if (lastTimeStamp == null) {
        fetchNewData = true;
    } else {
        // We've cached the service at least once. Check the last timestamp.
        var timeStamp = new Date(lastTimeStamp);
        if ((timeStamp.getTime() + (myXhrDefs.intCacheDuration * 1000)) < now.getTime()) {
          fetchNewData = true;
        }
    }

    // If we need to fetch new data, we need to extend the existing successCallback method
    // to cache the new results with a new timestamp.
    if (fetchNewData) {
        myXhrDefs.successCallback = (function(oldCallback) {
            function extendedCallback(objEvent) {
                localStorage.setItem(this.cacheName + "-data", objEvent.responseText);
                localStorage.setItem(this.cacheName + "-timestamp", now.toISOString());
                oldCallback(objEvent);
            }
            return extendedCallback;
        })(myXhrDefs.successCallback);

        // Perform the XHR request.
        doXHR(myXhrDefs);
    } else {
        // Just use the cached data.
        var cachedData = localStorage.getItem(myXhrDefs.cacheName + "-data"),
            fakeEvent = {
                responseText : cachedData
            };
        myXhrDefs.successCallback(fakeEvent);
    }
}
