(function() {
    var window = this,
        undefined;

    jkl = window.jkl = function(selector) {
        return new jkl.jklm.init(selector);
    }

    jkl.jklm = jkl.prototype = {
        init: function(selector) {
            this.selector = selector;
            return this;  
        }
    }
    jkl.jklm.init.prototype = jkl.jklm;
})();
