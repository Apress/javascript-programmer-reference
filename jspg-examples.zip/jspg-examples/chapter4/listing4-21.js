(function() {
    var window = this,
        undefined;

    jkl = window.jkl = function(selector) {
        return new jkl.jklm.init(selector);
    }

    jkl.jklm = jkl.prototype = {
        init: function(selector) {
            this.selector = selector;
            return this;  
        },

        // Hide the target element.
        hide : function() {
            document.querySelector(selector).style.display = "none";
            return this;
        },

        // Show the target element.
        show : function() {
            document.querySelector(selector).style.display = "inherit";
            return this;
        },

        // Make the target element red
        enredden : function() {
            document.querySelector(this.selector).style.backgroundColor = "#F00";
            return this;
        }
    }
    jkl.jklm.init.prototype = jkl.jklm;
})();
