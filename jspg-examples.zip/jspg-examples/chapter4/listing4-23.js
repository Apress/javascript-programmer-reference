(function() {
    var window = this,
        undefined;

    jkl = window.jkl = function(selector) {
        return new jkl.jklm.init(selector);
    }

    jkl.jklm = jkl.prototype = {
        init: function(selector) {
            this.selector = selector;
            return this;  
        },
        // Hide the target element.
        hide : function() {
            document.querySelector(selector).style.display = "none";
            return this;
        },

        // Show the target element.
        show : function() {
            document.querySelector(selector).style.display = "inherit";
            return this;
        },

        // Make the target element red
        enredden : function() {
            document.querySelector(this.selector).style.backgroundColor = "#F00";
            return this;
        },

        // Perform an asynchronous request defined by myXhrDefs object.
        doXHR : function(myXhrDefs) {
            // Create and configure a new XMLHttpRequest object
            var myXhr = new XMLHttpRequest(),
                myTimer = null;
            myXhr.open(myXhrDefs.strMethod, myXhrDefs.strUrl, myXhrDefs.boolAsync);
            // Register the error and success handlers
            myXhr.onreadystatechange = function(objEvent) {
                // If readyState is 4, request is complete.
                if (myXhr.readyState === 4) {
                    // Cancel the timeout timer if we set one.
                    if (myTimer !== null) {
                        clearTimeout(myTimer);
                    }
                    // If there's an error, call the error callback,
                    // Otherwise call the success callback.
                    if ((myXhr.status !== 200) && (myXhr.status !== 304)) {
                        if (myXhrDefs.errorCallback != null) {
                            myXhrDefs.errorCallback(myXhr);
                        }
                    } else {
                        myXhrDefs.successCallback(myXhr);
                    }
                }
            }
    
            // Handle timeouts (set myXhrDefs.intTimeout to null to skip)
            // If we're working with a newer implementation, we can just set the
            // timeout property and register the timeout callback.  
            // If not, we have to set a timer running that will execute the 
            // timeout callback.
            if (myXhrDefs.intTimeout !== null) {
                if (typeof myXhr.ontimeout !== "undefined") {
                    myXhr.timeout = myXhrDefs.intTimeout;
                    myXhr.ontimeout = myXhrDefs.timeoutCallback;
                } else {
                    myTimer = setTimeout(myXhrDefs.timeoutCallback, myXhrDefs.intTimeout);
                }        
            }
    
            // Send the request
            myXhr.send(myXhrDefs.postData); 
            return this;
        },

        // Execute a cross-domain JSONP query.
        executeJSONPQuery : function(strUrl) {
            // Check to see if a jsonp script tag has already been injected.
            // Also, create a new script tag with our new URL.
            var oldScript = document.getElementById("jsonp"),
                newScript = document.createElement("script");
            newScript.src = strUrl;
            newScript.id = "jsonp";
    
            // If there is already a jsonp script tag in the DOM we'll 
            // replace it with the new one.
            // Otherwise, we'll just append the new script tag to the DOM.
            if (oldScript !== null) {
                document.body.replaceChild(newScript, oldScript);
            } else {
                document.body.appendChild(newScript);
            }
            return this;
        },

        // Perform a cached XHR request.
        cachedXHR : function(myXhrDefs) {
            var fetchNewData = false,
                now = new Date(),
                lastTimeStamp = localStorage.getItem(myXhrDefs.cacheName + "-timestamp");
        
            // Does the cache even have the specified item?
            if (lastTimeStamp == null) {
                fetchNewData = true;
            } else {
                // We've cached the service at least once. Check the last timestamp.
                var timeStamp = new Date(lastTimeStamp);
                if ((timeStamp.getTime() + (myXhrDefs.intCacheDuration * 1000)) < now.getTime()) {
                  fetchNewData = true;
                }
            }

            // If we need to fetch new data, we need to extend the existing successCallback method
            // to cache the new results with a new timestamp.
            if (fetchNewData) {
                myXhrDefs.successCallback = (function(oldCallback) {
                    function extendedCallback(objEvent) {
                        localStorage.setItem(this.cacheName + "-data", objEvent.responseText);
                        localStorage.setItem(this.cacheName + "-timestamp", now.toISOString());
                        oldCallback(objEvent);
                    }
                    return extendedCallback;
                })(myXhrDefs.successCallback);

                // Perform the XHR request.
                doXHR(myXhrDefs);
            } else {
                // Just use the cached data.
                var cachedData = localStorage.getItem(myXhrDefs.cacheName + "-data"),
                    fakeEvent = {
                        responseText : cachedData
                    };
                myXhrDefs.successCallback(fakeEvent);
            }
            return this;
        },

        // Perform an asynchronous call to the specified URL and load the results into 
        // the target element.
        load : function(strUrl){
            var ptrTarget = document.querySelector(this.selector),
                myXhrDefs = {
                    strMethod : "GET",
                    strUrl : strUrl,
                    intTimeout: 3000,
                    postData: null,
                    boolAsync: true,
                    successCallback: function(objEvent) {
                        // Do things when the request is successful
                        ptrTarget.innerHTML = objEvent.responseText;
                    },
                    errorCallback: function(objEvent) {
                        // Do things when there is an error in the request.
                        console.error("The XHR failed with error ", objEvent.status);
                    },
                    timeoutCallback: function() {
                        // Do things when a timeout occurs.
                        console.error("The XHR timed out.");
                    }
                };
        
            this.doXHR(myXhrDefs);
            return this;
        }
    }
    jkl.jklm.init.prototype = jkl.jklm;
})();
