function handleReadyStateChange(objXHR) {
  if (objXHR.readyState === 4) {
    // Request is done.  Was the requested file found?
    If ((objXHR.status !== 200) && (objEvent.status !== 304)) {
      // Something happened..possibly the requested file wasn't found?
      // Tell the user that something went wrong.
      console.error("An error occurred while processing the request.");
    } else {
      // The requested file was found and sent and the content is now available in
      // the objXHR.responseText property:
      console.log(objXHR.responseText);
    }
  }
}
