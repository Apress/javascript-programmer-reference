var myXhrDefs = {
    strMethod : "GET",
    strUrl : "http://myhost.com/ajax-test.txt",
    intTimeout: 3000,
    postData: null,
    boolAsync: true,
    successCallback: function(objXHR) {
        // Do things when the request is successful
        console.log(objXHR.responseText);
    },
    errorCallback: function(objXHR) {
        // Do things when there is an error in the request.
        console.error("The XHR failed with error ", objXHR.status);
    },
    timeoutCallback: function() {
        // Do things when a timeout occurs.
        console.error("The XHR timed out.");
    }
}
