function doXHR(myXhrDefs) {

    // Create and configure a new XMLHttpRequest object
    var myXhr = new XMLHttpRequest(),
        myTimer = null;
    myXhr.open(myXhrDefs.strMethod, myXhrDefs.strUrl, myXhrDefs.boolAsync);

    // Register the error and success handlers
    myXhr.onreadystatechange = function() {

        // If readyState is 4, request is complete.
        if (myXhr.readyState === 4) {

            // Cancel the timeout timer if we set one.
            if (myTimer !== null) {
                clearTimeout(myTimer);
            }

            // If there's an error, call the error callback,
            // Otherwise call the success callback.
            if ((myXhr.status !== 200) && (myXhr.status !== 304)) {
                if (myXhrDefs.errorCallback != null) {
                    myXhrDefs.errorCallback(myXhr);
                }
            } else {
                myXhrDefs.successCallback(myXhr);
            }
        }
    }

    // Handle timeouts (set myXhrDefs.intTimeout to null to skip)
    // If we're working with a newer implementation, we can just set the
    // timeout property and register the timeout callback.  
    // If not, we have to set a start running that will execute the 
    // timeout callback. We can cancel the timer if/when the server responds.
    if (myXhrDefs.intTimeout !== null) {
        if (typeof myXhr.ontimeout !== "undefined") {
            myXhr.timeout = myXhrDefs.intTimeout;
            myXhr.ontimeout = myXhrDefs.timeoutCallback;
        } else {
            myTimer = setTimeout(myXhrDefs.timeoutCallback, myXhrDefs.intTimeout);
        }        
    }

    // Send the request
    myXhr.send(myXhrDefs.postData);
}
