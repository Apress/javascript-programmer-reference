function executeJSONPQuery(strUrl) {
    // Check to see if a jsonp script tag has already been injected.
    // Also, create a new script tag with our new URL.
    var oldScript = document.getElementById("jsonp"),
        newScript = document.createElement("script");
    newScript.src = strUrl;
    newScript.id = "jsonp";

    // If there is already a jsonp script tag in the DOM we'll 
    // replace it with the new one.
    // Otherwise, we'll just append the new script tag to the DOM.
    if (oldScript !== null) {
        document.body.replaceChild(newScript, oldScript);
    } else {
        document.body.appendChild(newScript);
    }
}
