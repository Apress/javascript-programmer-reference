// Initialize an empty array
var myArray = new Array(); // myArray will be empty--have a length of 0.
var myOtherArray = []; // Literal notation
var myLongArray = new Array(100); // length is 100.
alert(myLongArray[47]); // will alert "undefined"

// Initializing new arrays with values
var myFilledArray = new Array("this", "and", "the", "other"); 
var myIntegerArray = new Array(202, 53, 12, 0);
var myOtherFilledArray = ["more", "like", "this"];
var mySmallArrayOfDecimals = [0.1, 0.4];

// Constructing multidimensional arrays
var row1 = [1, 2, 3];
var row2 = [4, 5, 6];
var row3 = [7, 8, 9];
var array3by3 = [row1, row2, row3];  // array3by3 is now a multidimensional array
alert(array3by3[1][1]);  // alerts 5

// Constructing arrays of objects
var object1 = {
    "myName" : "object1"
};
var object2 = {
    "myName" : "object2"
};
var object3 = {
    "myName" : "object3"
};

var arrayOfObjects = [object1, object2, object3]; // arrayOfObjects now contains the objects
alert(arrayOfObjects[1].myName); // alerts "object2".
