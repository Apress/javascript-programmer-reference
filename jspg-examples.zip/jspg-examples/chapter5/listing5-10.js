var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var bunnies = myArray.shift(); // myArray is now ["kittens", "puppies", "ponies", "polar bear cubs"] and bunnies is now "bunnies"
