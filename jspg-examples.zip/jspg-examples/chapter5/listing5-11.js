var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var commonPets = myArray.slice(1, 2); // commonPets is now ["kittens", "puppies"];
var carnivores = myArray.slice(4, 5); // carnivores is now ["polar bear cubs"];
