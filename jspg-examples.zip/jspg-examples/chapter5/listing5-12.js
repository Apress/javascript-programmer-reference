var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
myArray.sort(); // myArray is now ["bunnies", "kittens", "polar bear cubs", "ponies", "puppies"]
var arrayOfIntegers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
arrayOfIntegers.sort(); // arrayOfIntegers is now [0, 1, 10, 11, 12, 13, 2, 3, 4, 5, 6, 7, 8, 9], which is possibly not useful
function mySortingFunction(a, b) {
    return a-b;
}
arrayOfIntegers.sort(mySortingFunction); // arrayOfIntegers is now [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
