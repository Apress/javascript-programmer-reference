var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var arrayOfPuppies = myArray.splice(2, 1); // This just removes "puppies" from myArray. arrayOfPuppies  is now ["puppies"]
var arrayOfKittens = myArray.splice(1, 1, "maru"); // arrayOfKittens is now ["kittens"] and myArray is now ["bunnies", "maru", "ponies", "polar bear cubs"];
var arrayOfPredators = ["velociraptors", "wolves"];
myArray.splice(2, 0, arrayOfPredators); // myArray is now ["bunnies", "maru", "ponies", ["velociraptors", "wolves"], "polar bear cubs"]
