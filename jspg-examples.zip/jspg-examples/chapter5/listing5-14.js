var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var strCuteThings = myArray.toString(); // strCuteThings now contains "bunnies,kittens,puppies,ponies,polar bear cubs"
