var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
myArray.unshift("chinchillas"); // myArray is now ["chinchillas", "bunnies", "kittens", "puppies", "ponies", "polar bear cubs"]
