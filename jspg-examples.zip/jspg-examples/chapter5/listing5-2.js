var myArray = ["this", "is", "an", "array"];
alert(myArray.length); // alerts 4
alert(myArray[myArray.length]); // alerts "undefined"; there is no such element with index of 4.
alert(myArray[myArray.length -1]); // alerts "array".
