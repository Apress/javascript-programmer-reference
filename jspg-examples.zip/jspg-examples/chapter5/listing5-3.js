var array1 = ["bunnies", "kittens", "puppies"];
var array2 = ["velociraptors"];
var array3 = array1.concat(array2); // array3 will now contain ["bunnies", "kittens", "puppies", "velociraptors"].
