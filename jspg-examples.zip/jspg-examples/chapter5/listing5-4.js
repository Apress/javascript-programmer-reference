var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var indexOfKittens = myArray.indexOf("kittens"); // 1
var indexOfVelociraptors = myArray.indexOf("velociraptors"); // -1
var indexOfPuppies = myArray.indexOf("puppies", -1); // this will return -1 because puppies is not contained within the subset specified by the starting index.
var indexOfPuppiesForReal = myArray.indexOf("puppies", -3); // 2
