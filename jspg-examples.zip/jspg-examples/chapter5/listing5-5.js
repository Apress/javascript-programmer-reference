var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var strCuteThings = myArray.join(); // strCuteThings now contains "bunnies,kittens,puppies,ponies,polar bear cubs"
var sentence = myArray.join(" are cute and ") + "are cute!"; // sentence now contains "bunnies are cute and kittens are cute and puppies are cute and ponies are cute and polar bear cubs are cute!" 
