var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs", "bunnies", "kittens"];
alert(myArray.lastIndexOf("bunnies")); // alerts 5
alert(myArray.lastIndexOf("ponies", 4)); // alerts -1
alert(myArray.lastIndexOf("kittens", -2)); // alerts 1
