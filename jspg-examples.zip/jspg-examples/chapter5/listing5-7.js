var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var cubs = myArray.pop(); // myArray is now ["bunnies", "kittens", "puppies", "ponies"] and cubs is now "polar bear cubs"
