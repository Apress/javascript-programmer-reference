var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
var newLength = myArray.push("chinchillas", "sugar gliders"); // newLength is 7
var predators = ["velociraptors", "wolves"];
newLength = myArray.push(predators); // newLength is 8 (not 9!)
alert(myArray[7]); // alerts "velociraptors,wolves"
alert(myArray[7][1]); // alerts "wolves"
