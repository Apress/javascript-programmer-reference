var myArray = ["bunnies", "kittens", "puppies", "ponies", "polar bear cubs"];
myArray.reverse(); // myArray is now  ["polar bear cubs", "ponies", "puppies", "kittens", "bunnies"];
