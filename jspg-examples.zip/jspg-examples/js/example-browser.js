(function() {
  // Set up our variables.
  var strHtml, 
      exampleContainer = document.getElementById("container-examples"),
      chapterContainer = document.getElementById("container-chapters"),
      runButton = document.getElementById("run-code"),
      nextButton = document.getElementById("next-example"),
      prevButton = document.getElementById("previous-example"),
      runButtonEventHandler,
      nextPrevButtonEventHandler,
      i,
      j;

  // Initialize the UI.
  // Create an unordered list of chapters based on the examples data structure.
  strHtml = "<ul>";
  for (i = 0; i < examples.length; i++) {
    strHtml += '<li data-chapter="' + i + '">Chapter ' + examples[i].number + ': ' + examples[i].title + '</li>'; 
  }
  strHtml += "</ul>";
  chapterContainer.innerHTML = strHtml;

  // Create an event handler object for the Run Button.  This object will
  // implement an event handler interface, and contain the properties and
  // methods needed to handle a click on the Run button.
  runButtonEventHandler = {
    targetIframe : document.getElementById("code-iframe"),
    targetScript : document.getElementById("dynamic-script"),
    textArea : document.getElementById("codearea"),
    exampleType : false,
    exampleUrl : "",
    handleEvent : function(event) {
      // This is the event handler interface.

      // Don't do anything if the button is disabled.
      if (event.target.classList.contains("disabled")) {
        return;
      }

      // Call the appropriate method based on the type of example.
      if (this.exampleType === "js") {
        this.runJsExample();
      } else {
        this.runHtmlExample();
      }
    },
    runHtmlExample : function() {
      var newText = document.getElementById("codearea").value,
      targetWindow = this.targetIframe.contentWindow.document;
      targetWindow.open();
      targetWindow.write(newText);
      targetWindow.close();
    },
    runJsExample : function() {
      var newText = document.getElementById("codearea").value,
          oldScript = document.getElementById("dynamic-script"),
          newScript = document.createElement("script");

      newScript.text = newText;
      newScript.id = "dynamic-script";

      if (oldScript !== null) {
          document.body.replaceChild(newScript, oldScript);
      } else {
          document.body.appendChild(newScript);
      }
    }
  };

  // Create the event handler object for the Next and Previous buttons.
  // This object will implement an event handler interface which will load
  // the proper example and handle updating the UI.
  nextPrevButtonEventHandler = {
    handleEvent : function(event) {
      var targetElement = event.target,
          chapterIndex,
          exampleIndex,
          oldExample,
          newExample,
          longSelector;

      // Internet Explorer doesn't implement data attributes.
      if (targetElement.dataset) {
        chapterIndex = targetElement.dataset.chapter;
        exampleIndex = targetElement.dataset.example;
      } else {
        chapterIndex = targetElement.getAttribute("data-chapter");
        exampleIndex = targetElement.getAttribute("data-example");
      }

      if (targetElement.classList.contains("disabled")) {
        // Don't do anything if the button is disabled.
        return;
      } else {
        loadExample(chapterIndex, exampleIndex);
      }
      
      oldExample = document.querySelector("#container-examples li.active");
      if (oldExample) {
        oldExample.classList.remove("active");
      }
      longSelector = '#container-examples li[data-example="' +
          exampleIndex + '"]';
      newExample = document.querySelector(longSelector);
      newExample.classList.add("active");
    }
  };

  // Bind the event handler objects.
  runButton.addEventListener("click", runButtonEventHandler, false);
  nextButton.addEventListener("click", nextPrevButtonEventHandler, false);
  prevButton.addEventListener("click", nextPrevButtonEventHandler, false);

  // This function loads an example.  It takes as parameters indices for the
  // desired chapter and index and fetches the needed information from the
  // examples data structure.
  function loadExample(strChapter, strExample) {
    var intChapter = parseInt(strChapter),
        intExample = parseInt(strExample),
        targetExample = examples[intChapter].examples[intExample],
        prevExample = examples[intChapter].examples[intExample - 1],
        nextExample = examples[intChapter].examples[intExample + 1],
        fullExampleIframe = document.querySelector(".container-fullexample"),
        newCodearea = document.createElement("textarea"),
        oldCodearea = document.getElementById("codearea"),
        targetEl = document.querySelector("#container-code div"),
        boolDataset = true;

    // Completely replace the textarea we are using as a code editor, so that
    // we have a blank slate to load in the new example.
    newCodearea.id = "codearea";
    targetEl.replaceChild(newCodearea, oldCodearea);

    // Check to see if data attributes are supported (IE does not support them).
    if ( typeof runButton.dataset === "undefined") {
      boolDataset = false;
    }

    // If the targetExample exists, load it into the code container so
    // it can be displayed.
    if (targetExample) {
      if (targetExample.type === "js") {
        jkl("#codearea").load(targetExample.url);
        fullExampleIframe.classList.add("disabled");
      } else {
        jkl("#container-code textarea").load(targetExample.url);
        fullExampleIframe.classList.remove("disabled");
      }

      // Update the properties on runButtonEventHandler so that if the 
      // user clicks the run button it will run the correct example.
      runButtonEventHandler.exampleType = targetExample.type;
      runButtonEventHandler.exampleUrl = targetExample.url;

      // Enable the run button, in case it was disabled.
      runButton.classList.remove("disabled");
    } else {
      // No example exists, so disable the run button.
      runButton.classList.add("disabled");
    }

    // If there is a previous example, 
    if (prevExample) {
      prevButton.classList.remove("disabled");
      if (boolDataset) {
        prevButton.dataset.chapter = intChapter;
        prevButton.dataset.example = intExample - 1;
      } else {
        prevButton.setAttribute("data-chapter", intChapter);
        prevButton.setAttribute("data-example", intExample - 1);
      }

    } else {
      prevButton.classList.add("disabled");
    }

    if (nextExample) {
      nextButton.classList.remove("disabled");
      if (boolDataset) {
        nextButton.dataset.chapter = intChapter;
        nextButton.dataset.example = intExample + 1;
      } else {
        nextButton.setAttribute("data-chapter", intChapter);
        nextButton.setAttribute("data-example", intExample + 1);
      }

    } else {
      nextButton.classList.add("disabled");
    }

  }

  // Delegate clicks on chapters to the chapterContainer.  That way we can
  // dynamically add or remove chapters as needed and not have to bind/unbind
  // their event handlers.
  chapterContainer.addEventListener("click", function(event) {
    var chapterIndex,
        targetElement = event.target, 
        oldChapter,
        i,
        strHtml;

    // Internet Explorer doesn't implement data attributes.
    if (typeof chapterContainer.dataset === "undefined") {
      chapterIndex = targetElement.getAttribute("data-chapter");
    } else {
      chapterIndex = targetElement.dataset.chapter;
    }

    strHtml = "<ul>";
    for (var i = 0; i < examples[chapterIndex].examples.length; i++) {
      strHtml += '<li data-chapter="'+chapterIndex+'" data-example="' + i + '">' +
      examples[chapterIndex].examples[i].number + ": " +
      examples[chapterIndex].examples[i].title + '</li>';
    }
    strHtml += "</ul>";
  
    exampleContainer.innerHTML = strHtml;

    oldChapter = document.querySelector("#container-chapters li.active");
    if (oldChapter) {
      oldChapter.classList.remove("active");
    }
    targetElement.classList.add("active");
  }, false);

  // Delegate clicks on examples to the exampleContainer. That way we can
  // dynamically add or remove examples as needed and not have to bind/unbind 
  // their event handlers.
  exampleContainer.addEventListener("click", function(event) {
    var chapterIndex,
        exampleIndex,
        targetElement = event.target,
        oldExample;

    // Internet Explorer doesn't implement data attributes.
    if (targetElement.dataset) {
      chapterIndex = targetElement.dataset.chapter;
      exampleIndex = targetElement.dataset.example;
    } else {
      chapterIndex = targetElement.getAttribute("data-chapter");
      exampleIndex = targetElement.getAttribute("data-example");
    }
    loadExample(chapterIndex, exampleIndex);

    // Finally, update the active state on the examples: remove it from the
    // previously-selected example (if there was one) and add it to the newly
    // selected example.
    oldExample = document.querySelector("#container-examples li.active");
    if (oldExample) {
      oldExample.classList.remove("active");
    }
    targetElement.classList.add("active");
  }, false);
})();

